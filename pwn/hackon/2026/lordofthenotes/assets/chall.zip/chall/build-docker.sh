docker build -t rapsolo .
docker run -d --name rapsolo_chall -p 1337:1337 rapsolo